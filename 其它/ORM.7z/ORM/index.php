<?php
/**
 * 纯粹的laravel-ORM操作
 * 2014年12月12日 18:10:41
 * 
 */

header("Content-type: text/html;charset=utf-8");

$config = [
  'driver'    => 'mysql',
  'host'      => 'localhost',
  'database'  => 'blog',
  'username'  => 'root',
  'password'  => '',
  'charset'   => 'utf8',
  'collation' => 'utf8_general_ci',
  'prefix'    => ''
  ];

require __DIR__.'/vendor/autoload.php';
use Illuminate\Database\Capsule\Manager as Capsule;
$capsule = new Capsule;
$capsule->addConnection($config);
$capsule->bootEloquent();

class Article extends Illuminate\Database\Eloquent\Model
{
  public $timestamps = false;
}

echo '<pre>';
$data=Article::first();
echo $data->title.'<br>';
echo '<hr/>';
$data=Article::all();
if($data){
    foreach($data as $item){
        echo $item->title.'<br>';
    }
}
echo '<hr/>';


