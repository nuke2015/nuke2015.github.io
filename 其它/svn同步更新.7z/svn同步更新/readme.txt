
此命令查出有更新的文件.
D:\advance\SlikSvn\bin>svnlook changed d:/mysvn -r 29
U   abc.txt
然后对这些文件进行分类,进行下一步的脚本操作.


