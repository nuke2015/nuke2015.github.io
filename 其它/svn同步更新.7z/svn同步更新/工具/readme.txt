把fslog.bat全局化
就能在post-commit.bat中直接使用了.

