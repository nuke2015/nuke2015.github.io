<?php 
	require_once(__DIR__."/easyCRUD.class.php");

	class Person  Extends Crud {
		
			# Your Table name 
			protected $table = 'persons';
			
			# Primary Key of the Table
			protected $pk	 = 'id';
	}

?>