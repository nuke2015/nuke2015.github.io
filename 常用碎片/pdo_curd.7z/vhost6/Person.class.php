<?php
require_once (__DIR__ . "/CRUD.class.php");

class Person Extends CRUD
{
    protected $table = 'persons';
    protected $pk = 'id';
}