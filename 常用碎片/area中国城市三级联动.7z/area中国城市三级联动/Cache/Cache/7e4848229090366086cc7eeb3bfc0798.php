<?php if (!defined('THINK_PATH')) exit();?><HTML>
 <HEAD>
  <TITLE> Ajax地域联动 </TITLE>
  <meta http-equiv=Content-Type content="text/html;charset=utf-8"/>
  <script type="text/javascript" src="__PUBLIC__/Js/jquery-1.7.2.min.js"></script>
  <script type="text/javascript" src="__PUBLIC__/Js/area.js"></script>
  <script>var ajaxurl="<?php echo U('Ajax/get');?>";</script>
 </HEAD>
 <BODY>
    <select name="province" id="province" onchange="loadArea(this.value,'city')">
        <option value="-1" selected>省份/直辖市</option>
        <?php if(is_array($province)): $i = 0; $__LIST__ = $province;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$area): $mod = ($i % 2 );++$i;?><option value="<?php echo ($area["aid"]); ?>"><?php echo ($area["title"]); ?></option><?php endforeach; endif; else: echo "" ;endif; ?>
    </select>
    <select name="city" id="city" onchange="loadArea(this.value,'district')">
        <option value="-1">市/县</option>
    </select>
    <select name="district" id="district" onchange="loadArea(this.value,'null')">
        <option value="-1">镇/区</option>
    </select>
 </BODY>
</HTML>