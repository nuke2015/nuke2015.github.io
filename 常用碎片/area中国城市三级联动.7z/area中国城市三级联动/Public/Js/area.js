function loadArea(pid,type) {
    $.post(ajaxurl,{'pid':pid},function(data){
        if(type=='city'){
           $('#'+type).html('<option value="-1">市/县</option>');
           $('#district').html('<option value="-1">镇/区</option>');
        }else if(type=='district'){
           $('#'+type).html('<option value="-1">镇/区</option>');
        }
		var json = eval(data); //json字符串转obj;
        if(type!='null'){
            $.each(json,function(){
                $('#'+type).append('<option value="'+this.aid+'">'+this.title+'</option>');
            });
        }
    });
}