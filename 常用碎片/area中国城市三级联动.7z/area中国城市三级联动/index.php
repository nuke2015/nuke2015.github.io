<?php
define('APP_DEBUG',true);
define('APP_NAME','Home');
define('APP_PATH','./Home/');
require './ThinkPHP/ThinkPHP.php';
header("Content-type: text/html;charset=utf-8");
ini_set('memory_limit','32M');
