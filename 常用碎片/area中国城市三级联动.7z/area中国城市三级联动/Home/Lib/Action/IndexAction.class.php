<?php
class IndexAction extends Action {
    public function index(){
        //获取省级地区
        $province=D('area')->where(array('pid'=>1))->select();
        $this->assign('province',$province);
        $this->display();
    }

}