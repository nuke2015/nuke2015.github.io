<?php
class AjaxAction extends Action {
    public function get(){
        $where['pid']=intval($_REQUEST['pid']);
        $area=D('area')->where($where)->select();
		$this->ajaxReturn($area);
    }
}